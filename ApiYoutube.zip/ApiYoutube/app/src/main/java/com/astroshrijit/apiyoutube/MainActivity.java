package com.astroshrijit.apiyoutube;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    Button add_video;
    ViewPager viewPager;
    CustomeSwipeAdpter customeSwipeAdpter;
    ListView listView;
    ArrayList<Model> arrayList=new ArrayList<>();
    GridAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        viewPager = (ViewPager) findViewById(R.id.view);
        listView = (ListView) findViewById(R.id.list1);

        customeSwipeAdpter = new CustomeSwipeAdpter(this);
        viewPager.setAdapter(customeSwipeAdpter);
        add_video = findViewById(R.id.add_video);
        add_video.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent add_video = new Intent(MainActivity.this, AddVideoActivity.class);
                startActivity(add_video);
                finish();
            }
        });

        arrayList.add(new Model("Coldplay","https://www.youtube.com/dvgZkm1xWPE",R.drawable.coldplay));
        arrayList.add(new Model("BYN","https://www.youtube.com/YOAD8MifiPg",R.drawable.byn));
        arrayList.add(new Model("Marjaavaan","https://www.youtube.com/qCgjpLEzBkg",R.drawable.marjavvan));
        arrayList.add(new Model("Jassi Gill","https://www.youtube.com/tjZ12mRqR20",R.drawable.jassie));
        arrayList.add(new Model("Naagin","https://www.youtube.com/Oi8q1zIGph0",R.drawable.naagin));
        adapter=new GridAdapter(arrayList,this);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent playerintent = new Intent(MainActivity.this,PlayerActivity.class);
                String s=arrayList.get(+position).link;
                String link=s.substring(s.lastIndexOf("/")+1);
                playerintent.putExtra("url",link);
                startActivity(playerintent);



            }
        });



    }
}
