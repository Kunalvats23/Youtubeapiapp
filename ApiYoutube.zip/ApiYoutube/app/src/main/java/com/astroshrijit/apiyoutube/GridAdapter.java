package com.astroshrijit.apiyoutube;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.text.BreakIterator;
import java.util.ArrayList;

public class GridAdapter extends BaseAdapter {
    ArrayList<Model> arrayList=new ArrayList<>();
    Context context;

    public GridAdapter(ArrayList<Model> arrayList, Context context) {
        this.arrayList = arrayList;
        this.context = context;
    }

    @Override
    public int getCount() {
        return arrayList.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }
    public class ViewHolder{
        TextView textView2;
        ImageView imageview;
        TextView textview;
    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {


        LayoutInflater inflater= (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        ViewHolder holder;

        if(view==null){
            holder=new ViewHolder();
            view=inflater.inflate(R.layout.listcontact,null);
            holder.imageview=view.findViewById(R.id.img_video_icon);
            holder.textview=view.findViewById(R.id.txt_video_title);
            holder.textView2=view.findViewById(R.id.txt_video_link);
            view.setTag(holder);
        }
        else {
            holder=(ViewHolder) view.getTag();
        }
        holder.imageview.setImageResource(arrayList.get(position).getImage());
        holder.textview.setText(arrayList.get(position).getName());
        holder.textView2.setText(arrayList.get(position).getLink());

        return view;
    }
}
